self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "bfaead0b1b822fb5a23243ca02b1b9fd",
    "url": "/index.html"
  },
  {
    "revision": "cc3191a7e12f7a83fb94",
    "url": "/static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "e7161885a22193046bc1",
    "url": "/static/css/main.981f7211.chunk.css"
  },
  {
    "revision": "cc3191a7e12f7a83fb94",
    "url": "/static/js/2.7770d795.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/static/js/2.7770d795.chunk.js.LICENSE.txt"
  },
  {
    "revision": "e7161885a22193046bc1",
    "url": "/static/js/main.1d96461e.chunk.js"
  },
  {
    "revision": "a3b9c9ad63a4094f2204",
    "url": "/static/js/runtime-main.e43661bb.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  }
]);